package com.example.autospruce;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * Auto spruce 2x2: dat 4 mam -> cho cay tu moc -> chat het log -> lap lai.
 * Khong dung bot xuong. Phim R de bat/tat. Minecraft 1.21.x (Yarn).
 * Dat 4 mam lien tuc, chat xong thi dung ngau nhien 1-5 giay roi lap lai.
 * Viet cho Minecraft 1.21.4.
 */
public class AutoSpruceClient implements ClientModInitializer {

    private static final int MIN_DELAY_TICKS = 20;   // 1 giay
    private static final int MAX_DELAY_TICKS = 100;  // 5 giay
    private static final int PLANT_GAP_TICKS = 2;    // khoang cach giua 2 lan dat mam
    private static final int RADIUS = 5;
    private static final double REACH = 4.5;

    private static final Random RNG = new Random();

    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static boolean chopping = false;
    private static int delay = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autospruce.toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, "category.autospruce"));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private static int randomDelay() {
        return MIN_DELAY_TICKS + RNG.nextInt(MAX_DELAY_TICKS - MIN_DELAY_TICKS + 1);
    }

    private void tick(MinecraftClient mc) {
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            chopping = false;
            delay = 0;
            if (mc.interactionManager != null) mc.interactionManager.cancelBlockBreaking();
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("AutoSpruce: " + (enabled ? "BAT" : "TAT")), true);
            }
        }
        if (!enabled || mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (delay > 0) { delay--; return; }

        ClientPlayerEntity p = mc.player;
        BlockPos origin = p.getBlockPos();

        // ===== 1) Chat log (thap nhat truoc) =====
        BlockPos log = findLowestLog(mc, p, origin);
        if (log != null) {
            chopping = true;
            selectAxe(p);
            lookAt(p, Vec3d.ofCenter(log));
            if (mc.interactionManager.updateBlockBreakingProgress(log, Direction.UP)) {
                p.swingHand(Hand.MAIN_HAND);
            }
            return;
        }

        if (chopping) {                 // vua chat xong -> dung 1-5s ngau nhien roi trong lai
            chopping = false;
            mc.interactionManager.cancelBlockBreaking();
            delay = randomDelay();
            return;
        }

        // ===== 2) Dat o 2x2 mam =====
        BlockPos best = null;
        int bestCount = -1;
        int y = origin.getY() - 1;
        for (int dx = -RADIUS; dx < RADIUS; dx++) {
            for (int dz = -RADIUS; dz < RADIUS; dz++) {
                BlockPos c = new BlockPos(origin.getX() + dx, y, origin.getZ() + dz);
                int count = countSaplings(mc, c);
                if (count > bestCount) { bestCount = count; best = c; }
            }
        }
        if (best == null || bestCount < 0) return;   // khong co cho trong 2x2
        if (bestCount == 4) return;                  // du 4 mam -> cho cay tu moc

        if (!selectItem(p, Items.SPRUCE_SAPLING)) return;

        for (int ox = 0; ox <= 1; ox++) {
            for (int oz = 0; oz <= 1; oz++) {
                BlockPos ground = best.add(ox, 0, oz);
                if (mc.world.getBlockState(ground.up()).isOf(Blocks.SPRUCE_SAPLING)) continue;
                Vec3d target = Vec3d.ofCenter(ground).add(0, 0.5, 0);
                if (target.distanceTo(p.getEyePos()) > REACH) continue;
                lookAt(p, target);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                        new BlockHitResult(target, Direction.UP, ground, false));
                p.swingHand(Hand.MAIN_HAND);
                delay = PLANT_GAP_TICKS;
                return;                              // moi tick chi dat 1 mam
            }
        }
    }

    /** Tra ve so mam da co (0-4) neu 2x2 hop le, -1 neu khong dat duoc. */
    private static int countSaplings(MinecraftClient mc, BlockPos c) {
        int count = 0;
        for (int ox = 0; ox <= 1; ox++) {
            for (int oz = 0; oz <= 1; oz++) {
                BlockPos g = c.add(ox, 0, oz);
                BlockState below = mc.world.getBlockState(g);
                BlockState above = mc.world.getBlockState(g.up());
                if (!below.isIn(BlockTags.DIRT)) return -1;
                if (above.isOf(Blocks.SPRUCE_SAPLING)) count++;
                else if (!above.isAir()) return -1;
            }
        }
        return count;
    }

    private static BlockPos findLowestLog(MinecraftClient mc, ClientPlayerEntity p, BlockPos origin) {
        BlockPos found = null;
        for (int dy = -1; dy <= 7; dy++) {
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    if (!mc.world.getBlockState(pos).isOf(Blocks.SPRUCE_LOG)) continue;
                    if (Vec3d.ofCenter(pos).distanceTo(p.getEyePos()) > REACH) continue;
                    if (found == null || pos.getY() < found.getY()) found = pos;
                }
            }
        }
        return found;
    }

    private static void lookAt(ClientPlayerEntity p, Vec3d t) {
        Vec3d eye = p.getEyePos();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        p.setPitch((float) -Math.toDegrees(Math.atan2(dy, h)));
    }

    private static boolean selectItem(ClientPlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(item)) {
                p.getInventory().setSelectedSlot(i);
                return true;
            }
        }
        return false;
    }

    private static void selectAxe(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isIn(ItemTags.AXES)) {
                p.getInventory().setSelectedSlot(i);
                return;
            }
        }
    }
}
